from __future__ import annotations
import asyncio
import time
import httpx
CHECK_EVERY = 120
DOWN_AFTER = 2
REMIND_AFTER = 6 * 3600
STREAK = 3
STREAK_WINDOW = 3600
LABELS = {'model': ('模型服务', 'model service'), 'browser': ('浏览器', 'browser'), 'sentinel': ('安全网关 Sentinel', 'Sentinel'), 'tasks': ('任务执行', 'task runs')}
CAUSES = {'model': '模型', 'browser': '浏览器', 'mail': '邮箱', 'sentinel': 'Sentinel', 'timeout': '超时', 'step_limit': '步数用完', 'gave_up': '来源反复失败', 'other': '其他'}

def failure_cause(error: str) -> str:
 e = str(error or '')
 low = e.lower()
 if 'llmerror' in low or '模型' in e or 'model api' in low or ('model unavailable' in low) or ('chat/completions' in low):
  return 'model'
 if '浏览器' in e or 'browser' in low or 'playwright' in low or ('chromium' in low):
  return 'browser'
 if any((k in low for k in ('gmail', 'imap', 'invalid_grant', 'oauth', 'mailbox'))) or '邮箱' in e:
  return 'mail'
 if 'sentinel' in low:
  return 'sentinel'
 if '用时上限' in e or 'time limit' in low or '超时' in e or ('timeout' in low):
  return 'timeout'
 if '步数上限' in e or 'step limit' in low:
  return 'step_limit'
 if '反复失败' in e or 'kept failing' in low or 'stopped retrying' in low:
  return 'gave_up'
 return 'other'

def model_check(models: list[dict], want: str) -> tuple[bool, str]:
 ids = [str(m.get('id') or '') for m in models]
 m = next((x for x in models if x.get('id') == want), None)
 if not m:
  return (False, f'模型 {want} 不在模型服务的列表里（可能已卸载或正在加载）；当前可用：{', '.join(ids[:5]) or '无'}')
 mode = str(m.get('mode') or 'chat').lower()
 if mode != 'chat':
  return (False, f'模型 {want} 不是聊天模型（mode={mode}）')
 ready = str(m.get('readiness') or 'ready').lower()
 if ready not in ('ready', 'running', 'loaded'):
  return (False, f'模型 {want} 还没就绪（{ready}）')
 return (True, f'{want} 正常')

class Health:

 def __init__(self, rt):
  self.rt = rt
  self.state: dict[str, dict] = {}
  self._task: asyncio.Task | None = None
  self.recent: list[dict] = []

 async def check_model(self) -> tuple[bool, str]:
  from app.runtime.llm import auth_headers
  s = self.rt.store.settings()
  base = str(s.get('model_base_url') or '').rstrip('/')
  if not base:
   return (False, '没有配置模型服务地址')
  try:
   async with httpx.AsyncClient(timeout=20) as c:
    r = await c.get(f'{base}/models', headers=auth_headers())
   if r.status_code >= 400:
    return (False, f'模型服务返回 HTTP {r.status_code}')
   models = [m for m in r.json().get('data') or [] if isinstance(m, dict)]
  except Exception as e:
   return (False, f'连不上模型服务：{type(e).__name__}')
  if not models:
   return (True, '模型服务在线（未列出模型）')
  return model_check(models, s.get('model_name') or '')

 async def check_browser(self) -> tuple[bool, str]:
  try:
   st = await self.rt.sentinel('GET', '/internal/browser_state', timeout=15)
  except Exception as e:
   return (False, f'连不上安全网关 Sentinel：{type(e).__name__}')
  if st.get('mode') in ('unknown', 'offline') or st.get('error'):
   return (False, f'浏览器服务不可用：{str(st.get('error') or '')[:120]}')
  return (True, '浏览器正常')

 async def run_checks(self) -> dict:
  out = {}
  out['model'] = await self.check_model()
  b_ok, b_detail = await self.check_browser()
  if not b_ok and 'Sentinel' in b_detail:
   out['sentinel'] = (False, b_detail)
  else:
   out['sentinel'] = (True, 'Sentinel 正常')
   out['browser'] = (b_ok, b_detail)
  return out

 async def observe(self, comp: str, ok: bool, detail: str, *, immediate: bool=False):
  now = time.time()
  st = self.state.setdefault(comp, {'ok': True, 'detail': '', 'fails': 0, 'since': now, 'alerted_at': 0.0, 'down': False})
  st['detail'] = detail
  st['checked_at'] = now
  if ok:
   st['fails'] = 0
   if st['down']:
    st['down'] = False
    st['since'] = now
    if st['alerted_at']:
     await self.alert(comp, f'已恢复正常：{detail}', recovered=True)
    st['alerted_at'] = 0.0
   st['ok'] = True
   return
  st['fails'] += 1
  st['ok'] = False
  if not st['down'] and (immediate or st['fails'] >= DOWN_AFTER):
   st['down'] = True
   st['since'] = now
  if st['down'] and now - st['alerted_at'] >= REMIND_AFTER:
   st['alerted_at'] = now
   await self.alert(comp, detail)

 async def alert(self, comp: str, detail: str, recovered: bool=False):
  en = self.rt.store.settings().get('language') == 'en'
  zh_name, en_name = LABELS.get(comp, (comp, comp))
  if recovered:
   title = f'✅ {en_name} is back' if en else f'✅ {zh_name}已恢复'
  else:
   title = f'🚨 OMuse: {en_name} problem' if en else f'🚨 OMuse：{zh_name}出问题了'
  body = detail + ('' if recovered else '\nNew tasks may fail until this is fixed.' if en else '\n修好之前，新任务可能会失败。')
  self.recent.append({'ts': time.time(), 'component': comp, 'title': title, 'body': body, 'recovered': recovered})
  del self.recent[:-50]
  try:
   n = self.rt.store.notify(title, body, level='info' if recovered else 'warning')
   await self.rt.publish({'kind': 'notification', 'notification': n})
  except Exception:
   pass
  try:
   await self.rt.sentinel('POST', '/internal/notify', {'task_id': '', 'text': f'{title}\n{body}'}, timeout=20)
  except Exception:
   pass

 async def on_task_finished(self, t: dict):
  if not t or t.get('source') == 'golden':
   return
  if t.get('status') == 'COMPLETED':
   if self.state.get('tasks', {}).get('down'):
    await self.observe('tasks', True, '任务又能正常完成了')
   return
  if t.get('status') != 'FAILED':
   return
  cause = failure_cause(t.get('error') or '')
  since = time.time() - STREAK_WINDOW
  rows = [r for r in self.rt.store.tasks('FAILED', 30) if (r.get('finished_at') or r.get('updated_at') or 0) >= since and r.get('source') != 'golden']
  same = [r for r in rows if failure_cause(r.get('error') or '') == cause]
  if len(same) >= STREAK:
   err = str(t.get('error') or '')[:200]
   await self.observe('tasks', False, f'最近 1 小时有 {len(same)} 个任务因{CAUSES.get(cause, cause)}问题失败：{err}', immediate=True)

 def status(self) -> dict:
  return {'components': {k: {kk: v.get(kk) for kk in ('ok', 'down', 'detail', 'since', 'checked_at')} for k, v in self.state.items()}, 'alerts': self.recent[-10:]}

 def start(self):
  if not self._task:
   self._task = asyncio.create_task(self._loop())

 async def _loop(self):
  await asyncio.sleep(20)
  while True:
   try:
    res = await self.run_checks()
    for comp, (ok, detail) in res.items():
     await self.observe(comp, ok, detail)
   except Exception as e:
    print(f'[health] check failed: {e!r}', flush=True)
   await asyncio.sleep(CHECK_EVERY)
